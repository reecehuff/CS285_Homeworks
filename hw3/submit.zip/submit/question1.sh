python cs285/scripts/run_hw3_dqn.py --env_name MsPacman-v0 --exp_name q1
